/**
 * php::base64编码器
 * Create at: 2022/04/17 02:04:37
 */

 'use strict';

 /*
 * @param  {String} pwd   连接密码
 * @param  {Array}  data  编码器处理前的 payload 数组
 * @return {Array}  data  编码器处理后的 payload 数组
 */
 
 module.exports = (pwd, data, ext={}) => {
 function xor(payload) {
     let crypto = require('crypto');
     let key = 'antsword2022';
     key = key.split("").map(t => t.charCodeAt(0));
     let cipher = payload.split("").map(t => t.charCodeAt(0));
     for (let i = 0; i < cipher.length; i++) {
       cipher[i] = cipher[i] ^ key[i % key.length]
     }
     cipher = cipher.map(t => String.fromCharCode(t)).join("")
     //return cipher;
     cipher = Buffer.from(cipher).toString('hex');
 
     return cipher;
   }
   // ##########    请在上方编写你自己的代码   ###################
   console.log(data['_']);
   let tmp = xor(data['_']);
   data[pwd] = tmp;
   delete data['_'];
   // 删除 _ 原有的payload
   // 返回编码器处理后的 payload 数组
   return data;
 }