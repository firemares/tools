//
// ASPX::microsoft_jet_oledb_4_0数据库驱动代码模板
//

module.exports = require('./access');